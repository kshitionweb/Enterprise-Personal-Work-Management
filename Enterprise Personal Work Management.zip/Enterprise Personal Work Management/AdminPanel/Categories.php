<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="https://fonts.googleapis.com/css?family=Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
		<!-- Website Font style -->
	    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.6.1/css/font-awesome.min.css">
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.13/css/dataTables.bootstrap.min.css">
		<link rel="stylesheet" href="https://cdn.datatables.net/responsive/2.1.1/css/responsive.bootstrap.min.css">
		<!-- Google Fonts -->
		<link href="https://fonts.googleapis.com/css?family=Raleway:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&subset=latin-ext" rel="stylesheet">

    </head>
    <body>
        <?php
        include 'AdminHeader.php';
        //require 'index.php';
        // put your code here
        ?>
        
<div class="container-fluid admin-content">
    
    <table id="example" class="table table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
        <thead>
            <tr>
                <th>Category</th>
                <th>Description</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Tiger</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tiger</td>
                <td>ixon</td>
            </tr>
            <tr>
                <td>iger</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tiger</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Ter</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tigr</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tige</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tiger</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Ter</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tigr</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tige</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tiger</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Ter</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tigr</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tige</td>
                <td>Nixon</td>
            </tr>
            <tr>
                <td>Tiger</td>
                <td>Nixon</td>
            </tr>
        </tbody>
    </table>
    <script>
    $(document).ready(function() {
    $('#example').DataTable();
} );</script>
    <script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
     <script src="https://cdn.datatables.net/1.10.13/js/dataTables.bootstrap.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.1.1/js/dataTables.responsive.min.js"></script>
      <script src="https://cdn.datatables.net/responsive/2.1.1/js/responsive.bootstrap.min.js"></script>
    </div>
        <?php
        //include 'footer.php';
        //require 'index.php';
        // put your code here
        ?>
    </body>
</html>

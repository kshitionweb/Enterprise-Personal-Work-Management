<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <script src="AdminStyles/jquery-1.11.1.min.js" type="text/javascript"></script>
        <link href="AdminStyles/bootstrap-3.2.0.min.css" rel="stylesheet" type="text/css"/>
        <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css">
        <script src="AdminStyles/bootstrap-3.2.0.min.js" type="text/javascript"></script>
        <link href="AdminStyles/AdminPanelStyle.css" rel="stylesheet" type="text/css"/>
    </head>
    <body>
       <div align="right" class="container-fluid dash-navbar">
            <a href="#">
                <img src="AdminStyles/AdminImages/dashboard-user-notification.png" class="dashboard-img-icon" alt=""/>   
            </a>
            <a href="#">
                <img src="AdminStyles/AdminImages/dashboard-user-email.png" class="dashboard-img-icon" alt=""/>
            </a>
            <div class="dropdown">
              <a href="#">
                <img src="AdminStyles/AdminImages/dashboard-user-account.png" class="dashboard-img-icon" alt=""/>
                My Account
              <span class="caret"></span></a>
              <div align="left" class="dropdown-content">
                  <a href="#">Profile</a>
                  <a href="#">Settings</a>
                  <a href="#">Logout</a>
              </div>
            </div>
        </div>
       <div class="nav-side-menu">
            <div class="brand"><a href='../index.php'>Website Name</a>
            <img src="AdminStyles/AdminImages/Admin1.jpeg" alt="" class="img-responsive admin-user"/>
            </div>
            <i class="fa fa-bars fa-2x toggle-btn" data-toggle="collapse" data-target="#menu-content"></i>
            <div class="menu-list">

                    <ul id="menu-content" class="menu-content collapse out">
                        <li>
                            <img src="AdminStyles/AdminImages/logo-dashboard.png" alt="" class="admin-menu-logo"/>
                            <a href='AdminDashboard.php' class="nav-links">Dashboard</a>
                        </li>
                        <li>
                            <img src="AdminStyles/AdminImages/logo-biography.png" alt="" class="admin-menu-logo"/>
                            <a href='Biography.php' class="nav-links">Biography</a>
                        </li>
                        <li>
                            <img src="AdminStyles/AdminImages/logo-category.png" alt="" class="admin-menu-logo"/>
                            <a href='Categories.php' class="nav-links">Categories</a>
                        </li>
                        </ul>
                         <li>
                             <a href="Employees.php" class="nav-links">Employees</a>
                        </li>
                         <li>
                            Page 5<a href="#"></a>
                        </li>
                        <li>
                            Page 6<a href="#"></a>
                        </li>
                        <li>
                            Page 7<a href="#"></a>
                        </li>
                        <li>
                            Page 8<a href="#"></a>
                        </li>
                    </ul>
             </div>
        </div>
</nav>
      <!--<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="#">About</a>
  <a href="#">Services</a>
  <a href="#">Clients</a>
  <a href="#">Contact</a>
</div>


  <span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>


<script>
function openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
}

function closeNav() {
    document.getElementById("mySidenav").style.width = "0";
    document.getElementById("main").style.marginLeft= "0";
}
</script>-->

    </div>
    </body>
</html>

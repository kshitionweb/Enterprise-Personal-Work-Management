<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title></title>
    </head>
    <body>
        <?php
        include 'header.php';
        //require 'index.php';
        // put your code here
        ?>
      <div id="slider">
        <div class="slides">
        <div class="slider">
          <div class="legend"></div>
          <div class="content">
            <div class="content-txt">
              <h1>Lorem ipsum dolor</h1>
              <h2>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</h2>
              <button type="button"  class="btnHomeCarousel" onClick="document.location.href='register.php'" >Join Now</button>
            </div>
          </div>
          <div class="image">
            <img src="Images/Before Login Images/HomeCarousel1.jpeg" alt=""/>
          </div>
        </div>
        <div class="slider">
          <div class="legend"></div>
          <div class="content">
            <div class="content-txt">
              <h1>Lorem ipsum dolor</h1>
              <h2>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</h2>
              <button type="button"  class="btnHomeCarousel" onClick="document.location.href='ourTeam.php'" >Know Our Community</button>
            </div>
          </div>
          <div class="image">
              <img src="Images/Before Login Images/HomeCarousel2.jpeg" alt=""/>
          </div>
        </div>
        <div class="slider">
          <div class="legend"></div>
          <div class="content">
            <div class="content-txt">
              <h1>Lorem ipsum dolor</h1>
              <h2>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</h2>
              <button type="button"  class="btnHomeCarousel" onClick="document.location.href='ourTeam.php'"  >Our Happy Clients</button>
            </div>
          </div>
          <div class="image">
              <img src="Images/Before Login Images/HomeCarousel3.jpg" alt=""/>
          </div>
        </div>
        <div class="slider">
          <div class="legend"></div>
          <div class="content">
            <div class="content-txt">
              <h1>Lorem ipsum dolor</h1>
              <h2>Nam ultrices pellentesque facilisis. In semper tellus mollis nisl pulvinar vitae vulputate lorem consequat. Fusce odio tortor, pretium sit amet auctor ut, ultrices vel nibh.</h2>
              <button type="button"  class="btnHomeCarousel" onClick="document.location.href='logIn.php'"  >Hire Now</button>
            </div>
          </div>
          <div class="image">
              <img src="Images/Before Login Images/HomeCarousel4.jpeg" alt=""/>
          </div>
        </div>
      </div>
        <div class="switch">
        <ul>
          <li>
            <div class="on"></div>
          </li>
          <li></li>
          <li></li>
          <li></li>
        </ul>
      </div>
      </div>  
      <div>
            <div class="home-below-carousel-section">
                <div class="container-fluid section-text">
                    <h2>Freelance Group’s best put together in one offer designed for businesses.</h2>
                </div>
                <div class="container-fluid section-head">
                    <h1>Get Up <span>Skill</span></h1>
                    <h3>Global solution to manage your project</h3>
                    <p>Toptal is an exclusive network of the top freelance experts in the world.
                        Top companies rely on Toptal freelancers for their most important projects.</p>
                </div>
                <img src="Images/Before Login Images/HomeBelowCarousel-img.png" />
            </div>
        </div>
      <div class="container section2">
            <div class="section2-head">
                <h2>Gain Access to a Network of Top Industry Experts</h2>
            </div>
            <div class="container"></div>
            <div class="row">
                <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <div class="card-body">
              <h4 class="card-title">
              <img src="Images/Before Login Images/HomeSection2 - img1.png" alt=""/>
                <label class="section2-text">Developers</label>
              </h4>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Amet numquam aspernatur eum quasi sapiente nesciunt? Voluptatibus sit, repellat sequi itaque deserunt, dolores in, nesciunt, illum tempora ex quae? Nihil, dolorem!</p>
                <button type="button"  class="section2-button" onClick="document.location.href='ourTeam.php'">Our Developers</button>
            </div>
          </div>
        </div>
                <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <div class="card-body">
              <h4 class="card-title">
                <img src="Images/Before Login Images/HomeSection2 - img2.png" alt=""/>
                <label class="section2-text">   Designers</label>
              </h4>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam viverra euismod odio, gravida pellentesque urna varius vitae.</p>
              <button type="button"  class="section2-button" onClick="document.location.href='ourTeam.php'" >Our Designers</button>
            </div>
          </div>
        </div>
                <div class="col-lg-4 col-sm-6 portfolio-item">
          <div class="card h-100">
            <div class="card-body">
              <h4 class="card-title">
               <img src="Images/Before Login Images/HomeSection2 - img3.png" alt=""/>
               <label class="section2-text"> Finance Experts</label>
              </h4>
              <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quos quisquam, error quod sed cumque, odio distinctio velit nostrum temporibus necessitatibus et facere atque iure perspiciatis mollitia recusandae vero vel quam!</p>
              <button type="button"  class="section2-button" onClick="document.location.href='ourTeam.php'" >Our Finance Experts</button>
            </div>
          </div>
        </div>
            </div>
            <div class="card-footer">
                <button type="button"  class="section2-viewAll-button" onClick="document.location.href='viewAllCategories.php'">View All Categories</button>
            </div>
      </div>
      <div class="container-fluid home-scope-section">
        <div class="row">
            <div class="col-md-3 scope-head">
                <p>
                    Hire for any scope of work:
                </p>
            </div>
            <div class="col-md-3 scope-content">
                <h3>
                    Short-term tasks
                </h3>
                <p>
                    Build a pool of diverse experts for one-off tasks
                </p>
            </div>
            <div class="col-md-3 scope-content">
                <h3>
                    Recurring projects
                </h3>
                <p>
                    Have a go-to team with specialized skills
                </p>
            </div>
            <div class="col-md-3 scope-content">
                <h3>
                    Full-time contract work
                </h3>
                <p>
                    Expand your staff with a dedicated team
                </p>
            </div>
        </div>
      </div>
      <div class="section3-main">
        <div class="container section3">
            <div class="row">
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img1.png" alt=""/>
            <p>Register with us</p>  
      </div>  
      </div>
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img2.png" alt=""/>
            <p>Any company</p>  
      </div> 
      </div>
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img3.png" alt=""/>
            <p>Check out our happy clients</p>  
      </div> 
      </div>
    </div>
            <div class="row">
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img4.png" alt=""/>
            <p>Check out our employees</p>  
      </div> 
      </div>
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img5.png" alt=""/>
            <p>Superior work</p>
      </div>
      </div>
      <div class="col-md-4">
        <div class="section3-content">
            <img src="Images/Before Login Images/HomeSection3-img6.png" alt=""/>
            <p>Read our blogs for more info</p>
      </div>
      </div>
    </div>
        </div>
    </div>
      <div class="section4">
        <img src="Images/Before Login Images/HomeSection4Image.jpg" alt="Home-Section4"/>
        <div class="centered">
            <h1>We Reunite Families</h1>
            <h2>Our GetSkill community contains thousands of skilled employees from around the world.</h2>
        </div>
      </div>
      <div>
        <div class="container section5">
            <div class="section5-head">
                <h2>Trusted By</h2>
            </div>
            <div class="row">
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img1.png" alt="" height="90" width="100"/>
                </div>
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img2.png" alt="" height="50" width="150"/>
                </div>
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img3.png" alt="" height="50" width="150"/>
                </div>
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img4.png" alt="" height="50" width="100"/>
                </div>
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img5.png" alt="" height="50" width="150"/>
                </div>
                <div class="col-md-2">
                    <img src="Images/Before Login Images/HomeSection5Img6.png" alt="" height="50" width="150"/>
                </div>
            </div>
            <div class="section5-footer">
                <p>And Many More</p>
            </div>
        </div>
      </div>
        <?php
        include 'footer.php';
        //require 'index.php';
        // put your code here
        ?>
    </body>
</html>

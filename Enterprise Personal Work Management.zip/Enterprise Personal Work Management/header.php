<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="Styles/jquery-3.3.1.min.js" type="text/javascript"></script>
        <link href="Styles/bootstrap-4.1.0.min.css" rel="stylesheet" type="text/css"/>
        <script src="Styles/bootstrap-4.1.0.min.js" type="text/javascript"></script>
        <script src="Styles/popper-1.14.0.min.js" type="text/javascript"></script>
        <link href="Styles/fontawesome.min.css" rel="stylesheet" type="text/css"/>
        <link href="Styles/MainStyle.css" rel="stylesheet" type="text/css"/>
        <title></title>
    </head>
    <body>
        <nav class="navbar fixed-top navbar-expand-lg before-login-nav">
          <a class="navbar-brand" href="#">Get Up Skill</a>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="nav navbar-nav mr-auto"></ul>
        <ul class="navbar-nav">
          <li class="nav-item active">
              <a class="nav-link" href="index.php">Home <span class="sr-only">(current)</span></a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href='AdminPanel/AdminDashboard.php'>Admin</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="howItWorks.php">How It Works</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="why.php">Why !</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="viewAllCategories.php">View All Categories</a>
          </li>
          <li class="nav-item">
              <a class="nav-link" href="ourTeam.php">Our Team</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="contactUs.php">Contact Us</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="logIn.php">Log In</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="register.php">Register</a>
          </li>
          <li class="nav-item">
              <a class="nav-link disabled" href="blog.php">Blog</a>
          </li>
       </ul>
  </div>
        </nav>
        <?php
        // put your code here
        ?>
    </body>
</html>
